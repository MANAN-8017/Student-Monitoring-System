<link rel="stylesheet" href="style.css">

<div class="container">

    <h1>Update Student's Attendance,</h1>

    <form method="post">
        <ul>
            <li><a href="UpdateHW.php">Hardware Workshop</a></li><br>
            <li><a href="UpdatePPS.php">PPS-II</a></li><br>
            <li><a href="UpdateMaths.php">Mathematics-II</a></li><br>
            <li><a href="UpdateSCP.php">Semiconductor Physics</a></li><br>
            <li><a href="UpdateEnglish.php">English</a></li><br>
            <li><a href="UpdateEVS.php">EVS</a></li><br>
        </ul>
        <div class="action">
            <a href=index.php id="back">Back</a>
        </div>
    </form>
</div>